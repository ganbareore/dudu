$(function (){
    //所有元素
    $('body').fontFlex(12,64,70)
})